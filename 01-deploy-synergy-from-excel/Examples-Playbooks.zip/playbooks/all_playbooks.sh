# Configure time locale 
echo -------
echo         Configure time locale  
echo -------
echo
ansible-playbook  /home/dung/ansible-scripts/playbooks/settings/timelocale.yml


# Configure address pool and subnet 
echo -------
echo         Configure address pool and subnet  
echo -------
echo
ansible-playbook  /home/dung/ansible-scripts/playbooks/settings/addresspool.yml


# Step 1 - Configure firmware baseline 
echo -------
echo         Step 1 - Configure firmware baseline  
echo -------
echo
ansible-playbook  /home/dung/ansible-scripts/playbooks/appliance/firmwarebaseline.yml


# Step 2 - Configure scope 
echo -------
echo         Step 2 - Configure scope  
echo -------
echo
ansible-playbook  /home/dung/ansible-scripts/playbooks/settings/scope.yml


# Step 3 - Configure Ethernet network 
echo -------
echo         Step 3 - Configure Ethernet network  
echo -------
echo
ansible-playbook  /home/dung/ansible-scripts/playbooks/networking/ethernetnetwork.yml


# Step 4 - Configure fc/fcoe network 
echo -------
echo         Step 4 - Configure fc/fcoe network  
echo -------
echo
ansible-playbook  /home/dung/ansible-scripts/playbooks/networking/fcnetwork.yml


# Step 5 - Configure network set
echo -------
echo         Step 5 - Configure network set 
echo -------
echo
ansible-playbook  /home/dung/ansible-scripts/playbooks/networking/networkset.yml


# Step 6 - Configure logical interconnectgroup
echo -------
echo         Step 6 - Configure logical interconnectgroup 
echo -------
echo
ansible-playbook  /home/dung/ansible-scripts/playbooks/networking/logicalinterconnectgroup.yml


# Step 7 - Configure enclosure group
echo -------
echo         Step 7 - Configure enclosure group 
echo -------
echo
ansible-playbook  /home/dung/ansible-scripts/playbooks/servers/enclosuregroup.yml


# Step 8 - Configure logical enclosure
echo -------
echo         Step 8 - Configure logical enclosure 
echo -------
echo
ansible-playbook  /home/dung/ansible-scripts/playbooks/servers/logicalenclosure.yml


# Step 9 - Configure profile template
echo -------
echo         Step 9 - Configure profile template 
echo -------
echo
ansible-playbook  /home/dung/ansible-scripts/playbooks/servers/profiletemplate.yml


# Step 10 - Configure profile
echo -------
echo         Step 10 - Configure profile 
echo -------
echo
ansible-playbook  /home/dung/ansible-scripts/playbooks/servers/profile.yml

